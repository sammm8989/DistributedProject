package be.kuleuven.bus;

public enum BoardingLocation {
    LEUVEN, AARSCHOT, HOEGAARDEN, NONE;
}
