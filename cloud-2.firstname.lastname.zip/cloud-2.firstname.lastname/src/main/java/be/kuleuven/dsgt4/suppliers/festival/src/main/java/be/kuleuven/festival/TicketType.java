package be.kuleuven.festival;

public enum TicketType {
    COMBI, FRIDAY, SATURDAY, SUNDAY
}
