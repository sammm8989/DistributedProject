#curl -X GET "localhost:8100/camping/tickets/available?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=158165"
curl -X GET "dsgt.canadacentral.cloudapp.azure.com:8100/camping/tickets/available?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=158165"
