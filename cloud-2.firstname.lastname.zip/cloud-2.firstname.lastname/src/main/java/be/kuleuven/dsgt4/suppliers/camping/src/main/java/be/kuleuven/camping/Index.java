package be.kuleuven.camping;

public class Index {
    private String name;

    public Index(){
        name = "Index Page";
    }

    public String getString() {
        return name;
    }

    public void setString(String name) {
        name = name;
    }

}