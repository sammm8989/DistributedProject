#curl -X GET "localhost:8100/camping/tickets?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=1574"
curl -X GET "dsgt.canadacentral.cloudapp.azure.com:8100/camping/tickets?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=1574"
