curl -X GET "localhost:8110/bus/tickets/available?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=56421"
#curl -X GET "dsgt.uksouth.cloudapp.azure.com:8110/bus/tickets/available?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=56421"
