curl -X POST "localhost:8090/festival/order?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=747474" -H 'Content-type:application/json' -d @new-order.json -v

#curl -X POST "dsgt2024team13.japaneast.cloudapp.azure.com:8090/festival/order?authentication=22a2856ae257c55c390215f69bb4c071862c2f3d0ede762058f3508f95f482a1&number=747474" -H 'Content-type:application/json' -d @new-order.json -v
