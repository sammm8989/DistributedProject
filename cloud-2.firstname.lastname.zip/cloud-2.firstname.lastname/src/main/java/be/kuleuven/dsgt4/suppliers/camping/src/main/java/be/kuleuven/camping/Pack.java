package be.kuleuven.camping;


public enum Pack{
    TENT, CAMPER, HOTEL, NONE
}
